# BETMASTER AI — Starter

A beginner-friendly Streamlit starter app for betting math and casino-game learning.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run `pip install -r requirements.txt`.
4. Run `streamlit run app.py`.

## Deploy
Deploy this repository with Streamlit Community Cloud and set the main file to `app.py`.

## Current limitations
This starter dashboard does not connect to sportsbooks or fetch live odds, schedules,
statistics, injuries, or lineups. It does not generate guaranteed picks or place bets.
The bet tracker is session-only. Gambling involves risk; never wager money you cannot
afford to lose.
