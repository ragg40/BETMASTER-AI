import streamlit as st
from betmaster.calculations import (
    american_to_decimal, implied_probability, expected_value,
    baccarat_reference, blackjack_hint
)

st.set_page_config(page_title="BETMASTER AI", page_icon="🎯", layout="wide")
st.title("🎯 BETMASTER AI")
st.caption("A starter dashboard for betting math, tracking, and casino-game learning.")
st.warning(
    "This starter app does not provide live odds, injury feeds, guaranteed picks, "
    "or automatic bet placement. Use it for education and calculations only."
)

odds_tab, tracker_tab, casino_tab = st.tabs(
    ["Odds & EV Calculator", "Bet Tracker", "Casino Math"]
)

with odds_tab:
    st.subheader("American odds calculator")
    odds = st.number_input("American odds", value=150, step=5)
    stake = st.number_input("Stake ($)", min_value=0.0, value=10.0, step=1.0)
    probability = st.slider("Your estimated chance of winning", 0.0, 1.0, 0.55, 0.01)
    decimal_odds = american_to_decimal(int(odds))
    implied = implied_probability(int(odds))
    ev = expected_value(stake, int(odds), probability)
    c1, c2, c3 = st.columns(3)
    c1.metric("Decimal odds", f"{decimal_odds:.3f}")
    c2.metric("Break-even probability", f"{implied:.1%}")
    c3.metric("Estimated expected value", f"${ev:.2f}")
    st.caption("Expected value depends on the accuracy of your probability estimate.")

with tracker_tab:
    st.subheader("Session-only bet tracker")
    if "bets" not in st.session_state:
        st.session_state.bets = []
    with st.form("bet_form"):
        description = st.text_input("Bet description")
        bet_stake = st.number_input(
            "Stake ($)", min_value=0.0, value=10.0, step=1.0, key="tracker_stake"
        )
        bet_odds = st.number_input("American odds", value=100, step=5, key="tracker_odds")
        submitted = st.form_submit_button("Add bet")
        if submitted and description.strip():
            st.session_state.bets.append({
                "Bet": description.strip(), "Stake": bet_stake, "Odds": int(bet_odds)
            })
    if st.session_state.bets:
        st.dataframe(st.session_state.bets, use_container_width=True)
        if st.button("Clear session bets"):
            st.session_state.bets = []
            st.rerun()
    else:
        st.info("No bets entered in this session. Entries are not saved permanently.")

with casino_tab:
    st.subheader("Baccarat reference")
    refs = baccarat_reference()
    st.write("Approximate probabilities for a common eight-deck game:")
    st.table({
        "Outcome": list(refs.keys()),
        "Approx. probability": [f"{v:.2%}" for v in refs.values()]
    })
    st.caption(
        "Past results do not predict the next baccarat hand. Banker commission and "
        "table rules affect payouts."
    )
    st.subheader("Basic blackjack learning hint")
    player = st.number_input("Your hand total", min_value=2, max_value=21, value=16)
    dealer = st.number_input("Dealer up-card (11 = Ace)", min_value=2, max_value=11, value=10)
    st.info(blackjack_hint(int(player), int(dealer)))
    st.caption(
        "Simplified educational hint only; soft hands, splits, and table rules require "
        "a complete strategy chart."
    )
