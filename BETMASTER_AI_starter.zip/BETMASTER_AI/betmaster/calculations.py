"""Educational betting and casino math helpers."""

def american_to_decimal(odds: int) -> float:
    if odds == 0:
        raise ValueError("American odds cannot be zero.")
    return 1 + (odds / 100 if odds > 0 else 100 / abs(odds))

def implied_probability(odds: int) -> float:
    if odds == 0:
        raise ValueError("American odds cannot be zero.")
    return 100 / (odds + 100) if odds > 0 else abs(odds) / (abs(odds) + 100)

def expected_value(stake: float, odds: int, win_probability: float) -> float:
    if not 0 <= win_probability <= 1:
        raise ValueError("Win probability must be between 0 and 1.")
    decimal_odds = american_to_decimal(odds)
    profit_if_win = stake * (decimal_odds - 1)
    return win_probability * profit_if_win - (1 - win_probability) * stake

def baccarat_reference() -> dict:
    # Approximate standard eight-deck probabilities.
    return {"Player": 0.4462, "Banker": 0.4586, "Tie": 0.0952}

def blackjack_hint(player_total: int, dealer_upcard: int) -> str:
    if player_total >= 17:
        return "Simplified hint: usually stand on 17 or higher."
    if player_total <= 11:
        return "Simplified hint: usually hit on 11 or lower."
    if player_total == 12 and 4 <= dealer_upcard <= 6:
        return "Simplified hint: usually stand on 12 against dealer 4–6."
    if 13 <= player_total <= 16 and 2 <= dealer_upcard <= 6:
        return "Simplified hint: usually stand on 13–16 against dealer 2–6."
    return "Simplified hint: this often calls for a hit; consult a full chart for your table rules."
